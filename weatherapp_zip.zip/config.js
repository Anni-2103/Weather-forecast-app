 
var apiKey = '4069622d7ae75b617e234903a9cdfdcb';   // openweatherapi key
